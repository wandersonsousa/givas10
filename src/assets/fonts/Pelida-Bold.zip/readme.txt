Thank you for get this typeface!

This font was designed to be useful to latin and greek languages. 
If you want the complete set of Imelda, please don't doubt it. Write me to david.ignorant@gmail.com or d.espinosa.mar@gmail.com ,  or david.ignorant@gmail.com

Copyright 2012. David Espinosa Type Foundry.
